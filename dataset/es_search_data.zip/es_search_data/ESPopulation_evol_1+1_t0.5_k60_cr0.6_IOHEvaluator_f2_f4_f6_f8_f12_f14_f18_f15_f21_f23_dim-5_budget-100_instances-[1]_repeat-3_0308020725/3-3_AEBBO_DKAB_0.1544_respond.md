# Description
**Adaptive Exploration Bayesian Optimization with Dynamic Kernel and Acquisition Balancing (AEBBO-DKAB):** This algorithm refines AEBBO by introducing a dynamic kernel adaptation strategy and a more sophisticated acquisition function balancing mechanism. The kernel's length scale is dynamically adjusted based on the optimization progress and data distribution. The balance between EI and UCB is dynamically adjusted based on the uncertainty of the GP model and the exploration progress.

# Justification
1.  **Dynamic Kernel Adaptation:** The original AEBBO uses a fixed kernel. However, the optimal kernel parameters can change during the optimization process. By dynamically adjusting the length scale of the RBF kernel based on the data, the GP model can better adapt to the local characteristics of the objective function. Specifically, the length scale is adjusted using the median distance between data points, which provides a robust estimate of the data distribution.
2.  **Adaptive Acquisition Balancing:** The balance between exploration (UCB) and exploitation (EI) is crucial for efficient optimization. The original AEBBO uses a simple linear decay for the exploration weight. The refined algorithm uses a more sophisticated approach that considers both the optimization progress and the uncertainty of the GP model. The exploration weight is adjusted based on the ratio of the average predicted standard deviation to the range of observed function values. This allows the algorithm to dynamically adjust the exploration-exploitation balance based on the characteristics of the objective function and the quality of the GP model.
3.  **Computational Efficiency:** The dynamic kernel adaptation and acquisition balancing are implemented in a computationally efficient manner, adding minimal overhead to the original AEBBO algorithm. The median distance calculation and the exploration weight adjustment are performed efficiently using numpy operations. The local search is retained to refine promising candidate solutions.

# Code
```python
from collections.abc import Callable
from scipy.stats import qmc #If you are using QMC sampling, qmc from scipy is encouraged. Remove this line if you have better alternatives.
from scipy.stats import norm
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel
from scipy.optimize import minimize
from scipy.spatial.distance import cdist

class AEBBO_DKAB:
    def __init__(self, budget:int, dim:int):
        self.budget = budget
        self.dim = dim
        # bounds has shape (2,<dimension>), bounds[0]: lower bound, bounds[1]: upper bound
        self.bounds = np.array([[-5.0]*dim, [5.0]*dim])
        # X has shape (n_points, n_dims), y has shape (n_points, 1)
        self.X: np.ndarray = None
        self.y: np.ndarray = None
        self.n_evals = 0 # the number of function evaluations
        self.n_init = 2 * dim # number of initial samples

        # Do not add any other arguments without a default value
        self.gp = None
        self.best_y = float('inf')
        self.best_x = None
        self.acq_strategy = "EI+UCB"
        self.initial_exploration_weight = 0.2
        self.exploration_weight = self.initial_exploration_weight
        self.batch_size = 2
        self.kernel_length_scale = 1.0

    def _sample_points(self, n_points):
        # sample points
        # return array of shape (n_points, n_dims)
        sampler = qmc.LatinHypercube(d=self.dim)
        samples = sampler.random(n=n_points)
        return qmc.scale(samples, self.bounds[0], self.bounds[1])

    def _fit_model(self, X, y):
        # Fit and tune surrogate model 
        # return the model
        # Do not change the function signature
        
        # Dynamic kernel adaptation
        distances = cdist(X, X, metric='euclidean')
        distances = np.triu(distances, k=1)
        median_distance = np.median(distances[distances > 0])
        self.kernel_length_scale = median_distance if median_distance > 0 else 1.0
        
        kernel = ConstantKernel(1.0, constant_value_bounds="fixed") * RBF(length_scale=self.kernel_length_scale, length_scale_bounds="fixed")
        self.gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=0, alpha=1e-6)
        self.gp.fit(X, y)
        return self.gp

    def _acquisition_function(self, X):
        # Implement acquisition function 
        # calculate the acquisition function value for each point in X
        # return array of shape (n_points, 1)
        if self.acq_strategy == "EI":
            return self._expected_improvement(X)
        elif self.acq_strategy == "UCB":
            return self._upper_confidence_bound(X)
        elif self.acq_strategy == "EI+UCB":
            ei = self._expected_improvement(X)
            ucb = self._upper_confidence_bound(X)
            return ei + self.exploration_weight * ucb
        else:
            raise ValueError("Invalid acquisition function strategy.")

    def _expected_improvement(self, X):
        mu, sigma = self.gp.predict(X, return_std=True)
        sigma = np.maximum(sigma, 1e-6)  # avoid division by zero
        gamma = (self.best_y - mu) / (sigma + 1e-9) # avoid division by zero
        ei = sigma * (gamma * norm.cdf(gamma) + norm.pdf(gamma))
        return ei.reshape(-1, 1)

    def _upper_confidence_bound(self, X):
        mu, sigma = self.gp.predict(X, return_std=True)
        return mu.reshape(-1, 1) + 2 * sigma.reshape(-1, 1)

    def _select_next_points(self, batch_size):
        # Select the next points to evaluate
        # Use a selection strategy to optimize/leverage the acquisition function 
        # The selection strategy can be any heuristic/evolutionary/mathematical/hybrid methods.
        # Your decision should consider the problem characteristics, acquisition function, and the computational efficiency.
        # return array of shape (batch_size, n_dims)
        
        selected_points = []
        candidates = self._sample_points(100 * self.dim) # Generate a larger candidate set
        
        for _ in range(batch_size):
            acq_values = self._acquisition_function(candidates)
            best_index = np.argmax(acq_values)
            selected_point = candidates[best_index]

            # Local search to refine the selected point
            def obj(x):
                return -self._acquisition_function(x.reshape(1, -1))[0, 0]  # Negate for minimization

            res = minimize(obj, selected_point, bounds=[(-5, 5)] * self.dim, method='L-BFGS-B')
            selected_point = res.x
            
            selected_points.append(selected_point)
            
            # Remove the selected point from the candidates to avoid duplicates in the batch
            candidates = np.delete(candidates, best_index, axis=0)
        
        return np.array(selected_points)

    def _evaluate_points(self, func, X):
        # Evaluate the points in X
        # func: takes array of shape (n_dims,) and returns np.float64.
        # return array of shape (n_points, 1)
        y = np.array([func(x) for x in X])
        self.n_evals += len(X)
        return y.reshape(-1, 1)
    
    def _update_eval_points(self, new_X, new_y):
        # Update self.X and self.y
        # Do not change the function signature
        if self.X is None:
            self.X = new_X
            self.y = new_y
        else:
            self.X = np.vstack((self.X, new_X))
            self.y = np.vstack((self.y, new_y))
            
        # Update best seen value
        best_index = np.argmin(self.y)
        if self.y[best_index][0] < self.best_y:
            self.best_y = self.y[best_index][0]
            self.best_x = self.X[best_index]
    
    def __call__(self, func:Callable[[np.ndarray], np.float64]) -> tuple[np.float64, np.array]:
        # Main minimize optimization loop
        # func: takes array of shape (n_dims,) and returns np.float64. 
        # !!! Do not call func directly. Use _evaluate_points instead and be aware of the budget when calling it. !!!
        # Return a tuple (best_y, best_x)
        
        # Initial sampling
        initial_X = self._sample_points(self.n_init)
        initial_y = self._evaluate_points(func, initial_X)
        self._update_eval_points(initial_X, initial_y)
        
        # Optimization loop
        while self.n_evals < self.budget:
            # Fit the GP model
            self._fit_model(self.X, self.y)

            # Select points by acquisition function
            next_X = self._select_next_points(min(self.batch_size, self.budget - self.n_evals))

            # Evaluate the selected points
            next_y = self._evaluate_points(func, next_X)
            self._update_eval_points(next_X, next_y)
            
            # Adaptive acquisition balancing
            mean_sigma = np.mean(self.gp.predict(self.X, return_std=True)[1])
            range_y = np.max(self.y) - np.min(self.y) if len(self.y) > 1 and np.max(self.y) != np.min(self.y) else 1.0
            self.exploration_weight = self.initial_exploration_weight * (mean_sigma / range_y) * (1 - self.n_evals / self.budget)
            self.exploration_weight = np.clip(self.exploration_weight, 0.01, self.initial_exploration_weight)

        return self.best_y, self.best_x
```
## Feedback
 The algorithm AEBBO_DKAB got an average Area over the convergence curve (AOCC, 1.0 is the best) score of 0.1544 with standard deviation 0.0987.

took 296.33 seconds to run.