# Description
**BAEHBBO-AKEEBLS-EILS-AdaptiveNoise-KernelTuning-Batch-ImprovedLocalSearch**: Budget-Aware Efficient Hybrid Bayesian Optimization with Adaptive Kernel, Exploration-Exploitation Balance, Local Search Refinement, Stochastic Local Search, Adaptive Noise Handling, Kernel Tuning, and Batch Evaluation. This version focuses on enhancing the local search strategy by incorporating a more robust sampling method around the L-BFGS-B solution and a more informed decision on whether to accept the local search result based on the GP's predictive variance. It also introduces a dynamic scaling factor for the local search sampling radius based on the remaining budget.

# Justification
The previous version's local search relied on a fixed number of samples around the L-BFGS-B solution. This can be inefficient, especially when the GP's uncertainty is high or low. The refined local search strategy addresses this by:

1.  **Adaptive Sampling Radius:** The standard deviation used for sampling around the L-BFGS-B solution is scaled by the remaining budget fraction. This allows for wider exploration early in the optimization process and finer exploitation as the budget dwindles.
2.  **Acceptance Criterion Based on Predictive Variance:** The algorithm now checks if the GP's predicted variance at the L-BFGS-B solution is below a threshold before performing the stochastic local search. This prevents unnecessary evaluations in regions where the GP is already confident.
3.  **Increased Local Search Iterations:** The number of L-BFGS-B iterations is increased to potentially find better local optima, but still limited by the remaining budget.
4. **Simplified diversity term:** The diversity term in the acquisition function is simplified to improve computational efficiency.

These changes aim to improve the efficiency and effectiveness of the local search, leading to better overall performance.

# Code
```python
from collections.abc import Callable
from scipy.stats import qmc
from scipy.stats import norm
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, Matern
from scipy.optimize import minimize
from sklearn.neighbors import NearestNeighbors
import warnings

class BAEHBBO_AKEEBLS_EILS_AdaptiveNoise_KernelTuning_Batch_ImprovedLocalSearch:
    def __init__(self, budget:int, dim:int):
        self.budget = budget
        self.dim = dim
        self.bounds = np.array([[-5.0]*dim, [5.0]*dim])
        self.X: np.ndarray = None
        self.y: np.ndarray = None
        self.n_evals = 0
        self.n_init = 2 * dim
        self.exploration_weight = 0.2  # Initial exploration weight
        self.initial_exploration_weight = 0.2
        self.local_search_variance_threshold = 0.1 # Threshold for GP variance to trigger local search

        # Do not add any other arguments without a default value

    def _sample_points(self, n_points):
        sampler = qmc.LatinHypercube(d=self.dim)
        samples = sampler.random(n=n_points)
        return qmc.scale(samples, self.bounds[0], self.bounds[1])

    def _estimate_noise(self, X, y, n_neighbors=5):
        """Estimates the noise level based on the variance of function values at nearby points."""
        if len(X) < n_neighbors:
            return 1e-6  # Return a small default noise if not enough points

        knn = NearestNeighbors(n_neighbors=min(n_neighbors, len(X)-1), algorithm='kd_tree')
        knn.fit(X)
        distances, indices = knn.kneighbors(X)
        
        # Calculate the variance of y values for each point's neighbors
        noise_estimates = np.var(y[indices[:, 1:]], axis=1) # Exclude the point itself
        
        # Return the median noise estimate
        return np.median(noise_estimates)

    def _fit_model(self, X, y):
        # Adaptive noise level estimation
        alpha = self._estimate_noise(X, y)
        
        # Kernel tuning: Optimize the kernel hyperparameters
        kernel = ConstantKernel(1.0, constant_value_bounds="fixed") * RBF(length_scale=1.0, length_scale_bounds=(1e-2, 1e2))  # Allow length scale to vary
        gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=3, alpha=alpha)  # Enable kernel optimization
        
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            gp.fit(X, y)
        return gp

    def _acquisition_function(self, X, gp, y_best, X_batch):
        mu, sigma = gp.predict(X, return_std=True)
        sigma = np.clip(sigma, 1e-9, np.inf)
        imp = mu - y_best
        Z = imp / sigma
        ei = imp * norm.cdf(Z) + sigma * norm.pdf(Z)
        
        # Exploration component (using UCB)
        ucb = mu + self.exploration_weight * sigma

        # Combine EI and UCB
        acquisition = ei + self.exploration_weight * ucb

        # Diversity term: Penalize points close to the best point
        if len(self.X) > 0:
            distances = np.linalg.norm(X - self.X[np.argmin(self.y)], axis=1)
            acquisition -= 0.01 / (distances + 1e-6)

        return acquisition

    def _acquisition_function_local_search(self, X, gp, y_best):
        mu, sigma = gp.predict(X, return_std=True)
        sigma = np.clip(sigma, 1e-9, np.inf)
        imp = mu - y_best
        Z = imp / sigma
        ei = imp * norm.cdf(Z) + sigma * norm.pdf(Z)
        return ei

    def _select_next_points(self, batch_size, gp, y_best):
        selected_X = []
        for _ in range(batch_size):
            best_x = None
            best_acq = -np.inf
            for _ in range(10 * batch_size):
                x = self._sample_points(1)
                acq = self._acquisition_function(x, gp, y_best, np.array(selected_X))
                if acq > best_acq:
                    best_acq = acq
                    best_x = x

            selected_X.append(best_x.flatten())
        return np.array(selected_X)

    def _evaluate_points(self, func, X):
        y = np.array([func(x) for x in X])
        self.n_evals += len(X)
        return y.reshape(-1, 1)
    
    def _update_eval_points(self, new_X, new_y):
        if self.X is None:
            self.X = new_X
            self.y = new_y
        else:
            self.X = np.vstack((self.X, new_X))
            self.y = np.vstack((self.y, new_y))
    
    def __call__(self, func:Callable[[np.ndarray], np.float64]) -> tuple[np.float64, np.array]:
        # Main minimize optimization loop
        # func: takes array of shape (n_dims,) and returns np.float64. 
        # !!! Do not call func directly. Use _evaluate_points instead and be aware of the budget when calling it. !!!
        # Return a tuple (best_y, best_x)
        
        # Initial sampling
        initial_X = self._sample_points(self.n_init)
        initial_y = self._evaluate_points(func, initial_X)
        self._update_eval_points(initial_X, initial_y)
        
        best_idx = np.argmin(self.y)
        best_y = self.y[best_idx][0]
        best_x = self.X[best_idx]

        while self.n_evals < self.budget:
            # Fit the GP model
            gp = self._fit_model(self.X, self.y)
            
            # Determine the batch size adaptively
            remaining_evals = self.budget - self.n_evals
            batch_size = min(max(1, remaining_evals // 5), 5)  # Adaptive batch size
            
            # Select the next points using EI
            next_X = self._select_next_points(batch_size, gp, best_y)
            
            # Evaluate the next points
            next_y = self._evaluate_points(func, next_X)
            self._update_eval_points(next_X, next_y)
            
            # Update the best solution
            best_idx = np.argmin(self.y)
            best_y = self.y[best_idx][0]
            best_x = self.X[best_idx]

            # Local search refinement using the surrogate model
            def surrogate_objective(x):
                return gp.predict(x.reshape(1, -1))[0]

            # Limit the number of iterations based on remaining budget
            max_iter = min(10, remaining_evals)  # Limit iterations, increased from 5
            if max_iter > 0:
                # Use L-BFGS-B for local search
                res = minimize(surrogate_objective, best_x, method='L-BFGS-B', bounds=list(zip(self.bounds[0], self.bounds[1])), options={'maxiter': max_iter, 'maxfun': max_iter})  # Limit function evaluations
                
                # Evaluate the result of the local search with the real function
                if self.n_evals < self.budget:
                    # Stochastic Local Search
                    # Check GP's variance at the L-BFGS-B solution
                    _, sigma_ls = gp.predict(res.x.reshape(1, -1), return_std=True)
                    sigma_ls = np.clip(sigma_ls, 1e-9, np.inf)[0]

                    if sigma_ls < self.local_search_variance_threshold:
                        num_samples = min(5, remaining_evals) # Sample at most 5 points
                        
                        refined_X = np.zeros((num_samples, self.dim))
                        refined_y = np.zeros(num_samples)
                        
                        # Adaptive sampling radius based on remaining budget
                        budget_fraction = (self.budget - self.n_evals) / self.budget
                        sampling_std = sigma_ls * budget_fraction # Scale the std
                        
                        for i in range(num_samples):
                            # Sample around the L-BFGS-B solution, scaling by GP's uncertainty
                            sample = np.random.normal(res.x, sampling_std, self.dim)
                            sample = np.clip(sample, self.bounds[0], self.bounds[1])  # Clip to bounds
                            refined_X[i, :] = sample
                        
                        refined_y = self._evaluate_points(func, refined_X)[:,0]
                        
                        best_refined_idx = np.argmin(refined_y)
                        if refined_y[best_refined_idx] < best_y:
                            best_y = refined_y[best_refined_idx]
                            best_x = refined_X[best_refined_idx]
            
            # Update exploration weight (adaptive decay based on budget)
            budget_fraction = (self.budget - self.n_evals) / self.budget
            self.exploration_weight = max(0.01, min(0.5, 0.5 * budget_fraction))

        return best_y, best_x
```
## Feedback
 The algorithm BAEHBBO_AKEEBLS_EILS_AdaptiveNoise_KernelTuning_Batch_ImprovedLocalSearch got an average Area over the convergence curve (AOCC, 1.0 is the best) score of 0.1398 with standard deviation 0.1024.

took 104.71 seconds to run.